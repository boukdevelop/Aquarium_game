
╔══════════════════════════════════════════════════════════════╗
║  DOSSIER DES ASSETS                                          ║
╚══════════════════════════════════════════════════════════════╝

Ce dossier contiendra :

📁 textures/
   ├── fish/          - Sprites des poissons
   ├── decorations/   - Sprites des décorations
   ├── ui/            - Éléments d'interface
   └── backgrounds/   - Arrière-plans

📁 fonts/
   └── Polices TTF

📁 sounds/
   ├── sfx/   - Effets sonores
   └── music/ - Musique d'ambiance

💡 Pour l'instant, le jeu utilise des formes géométriques simples.
   Les assets sont optionnels pour la version 1.0.

Consultez assets/README.md (à copier depuis les artifacts) 
pour plus d'informations.
